//
//  GameState.swift
//  RockPaperScissors
//
//  Created by Student on 4/28/24.
//

import Foundation

enum GameState {
    case start, win, lose, draw
    
    
}
