//
//  ViewController.swift
//  PersonalityQuiz
//
//  Created by student on 12/9/23.
//

import UIKit

class IntroductionViewController: UIViewController {
    
    @IBAction func unwindtoQuizIntroduction(segue: UIStoryboardSegue) {
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

